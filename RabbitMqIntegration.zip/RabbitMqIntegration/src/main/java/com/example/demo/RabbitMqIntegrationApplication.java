package com.example.demo;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.runner.ReactiveWebApplicationContextRunner;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class RabbitMqIntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitMqIntegrationApplication.class, args);
	}

	public static final String QUEUE = "playJavaQueue";
	public static final String EXCHANGE = "playJavaExchange";
	public static final String ROUTHING_KEY = "playJavaRouthingKey";

	@Bean
	public Queue queue() {
		return new Queue(QUEUE, false);
	}

	@Bean
	public DirectExchange exchange() {
		return new DirectExchange(EXCHANGE);
	}

	@Bean
	Binding binding(Queue queue, DirectExchange exchange) {
		return BindingBuilder.bind(queue).to(exchange).with(ROUTHING_KEY);
	}

}
