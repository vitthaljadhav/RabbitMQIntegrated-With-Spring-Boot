package com.example.demo;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "rabbit-test")
public class RabbitMqProducerController {
	@Autowired
	private AmqpTemplate amqpTemplate;

	@GetMapping(value="/produce")
	public String produce() {
		amqpTemplate.convertAndSend(RabbitMqIntegrationApplication.EXCHANGE,
				RabbitMqIntegrationApplication.ROUTHING_KEY, "Hello World Example !!!!! Throuht RabbitMQ!!!!");

		return "Data Produces";
	}
}
